#include "History.h"

History::History(int nRows, int nCols)
{
	h_Arena = Arena(nRows, nCols);

}
